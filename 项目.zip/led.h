#ifndef __LED_H__
#define __LED_H__
void judge_distance(unsigned int distance);
void Light_Close();
#endif