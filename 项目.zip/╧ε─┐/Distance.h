#ifndef __Distance_H__
#define __Distance_H__
void delayxus(unsigned int xus);
void Time1Init();
int Distance();
#endif