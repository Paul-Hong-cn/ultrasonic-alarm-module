#ifndef __Alarm_H__
#define __Alarm_H__
void Alarm_Init();
int Alarm1_Play(unsigned int s2,unsigned int times);
void MusicPlayer_TimerRoutine();
int Alarm_Close();

#endif